%% ---------------------------- 多输入单输出贝叶斯优化BiLSTM ----------------------------
clc; 
clear;
close all;
%% 参数设置
opt.learningMethod      = 'LSTM';
opt.trPercentage        = 0.80;                   %  训练集与预测集划分标准比例

% ---- 深度学习参数设置(LSTM and CNN General Parameters)
% opt.maxEpochs     = 50;%1-100                   % 最大迭代次数，可设置为优化目标.
opt.miniBatchSize = 32;                         % minimum batch size in deeplearning algorithms .可不设置
opt.executionEnvironment = 'cpu';                % 'cpu' 'gpu' 'auto'
opt.LR                   = 'adam';               % 'sgdm' 'rmsprop' 'adam'
opt.trainingProgress     = 'none';  % 'training-progress' 'none'

% ------------- BILSTM parameters
opt.isUseBiLSTMLayer  = true;                     % if it is true the layer turn to the Bidirectional-LSTM and if it is false it will turn the units to the simple LSTM
opt.isUseDropoutLayer = true;                    % dropout layer avoid of bieng overfit
opt.DropoutValue      = 0.5;                      %可不设置

% ------------ 优化参数
opt.optimVars = [
    optimizableVariable('NumOfLayer',[1 4],'Type','integer')%隐藏层个数
    optimizableVariable('NumOfUnits',[1 100],'Type','integer')%神经元个数[1,100]
    optimizableVariable('maxEpochs',[1 100],'Type','integer')%最大迭代次数
     optimizableVariable('isUseBiLSTMLayer',[1 2],'Type','integer')%优化LSTM结构，1代表BiLSTM，2代表lstm，数据类型为整数
    optimizableVariable('InitialLearnRate',[1e-3 1e-1],'Transform','log')%对数变换，初始学习率
    optimizableVariable('L2Regularization',[1e-10 1e-2],'Transform','log')];%L2正则化系数

opt.isUseOptimizer         = true;%是否选择贝叶斯优化


opt.MaxOptimizationTime    = 14*60*60;%优化运行的最大时间14*60*60
opt.MaxItrationNumber      = 80;%贝叶斯优化运行的最大迭代次数60
opt.isDispOptimizationLog  = true;%优化运行的最大迭代次数60

opt.isSaveOptimizedValue       = false;        %  save all of Optimization output on mat files 
opt.isSaveBestOptimizedValue   = false;        %  保存最佳优化输出一个mat文件true  
%% 数据导入与预处理
data_O = xlsread('newinput.xlsx','二次筛选');
inputdata = data_O(:,1:20);
outputdata = xlsread("output.xlsx",'原始数据');
inputdata = inputdata';
outputdata = outputdata';
X = inputdata;
Y = outputdata;
%% 数据集的划分
data.XTr   = [];
data.YTr   = [];
data.XTs   = [];
data.YTs   = [];
data.X     = [];
data.Y     = [];
data.X = X;
data.Y = Y;
numTrSample = 325;%round(opt.trPercentage*size(X,2));
%训练集
data.XTr   = X(:,1:numTrSample);
data.YTr   = Y(:,1:numTrSample);
[c1,d1]=mapminmax(data.XTr);%归一化处理
[c2,d2]=mapminmax(data.YTr);
[inputn1,inputps1]=mapminmax('apply',data.XTr,d1);
[outputn1,outputps1]=mapminmax('apply',data.YTr,d2);%%归一化处理
data.XTr = inputn1;
data.YTr = outputn1;
%测试集
data.XTs   = X(:,numTrSample+1:end);
data.YTs   = Y(:,numTrSample+1:end);
[c3,d3]=mapminmax(data.XTs);
[c4,d4]=mapminmax(data.YTs);
[inputn2,inputps2]=mapminmax('apply',data.XTs,d3);
[outputn2,outputps2]=mapminmax('apply',data.YTs,d4);%%归一化处理
data.XTs = inputn2;
data.YTs = outputn2;
% LSTM data form
data = LSTMInput(data);
%% --------------- 利用贝叶斯网络寻优
[opt,data] = OptimizeLSTM(opt,data);
%% --------------- 数据评估
    OptimizedParams =  evalin('base', 'OptimizedParams');
    % find best Net
    [valBest,indxBest] = sort(str2double(extractAfter(strrep(fieldnames(OptimizedParams),'_','.'),'Error')));
    data.BiLSTM.Net = OptimizedParams.(['ValidationError' strrep(num2str(valBest(1)),'.','_')]).Net;
    if opt.isSaveBestOptimizedValue
        fileName = ['BestNet ' num2str(valBest(1)) ' ' char(datetime('now','Format','yyyy.MM.dd HH.mm')) '.mat'];
        Net = data.BiLSTM.Net;
        save(fileName,'Net')
    end
Tr_output = predict(data.BiLSTM.Net,data.XTr,'MiniBatchSize',opt.miniBatchSize);
Tr_output = mapminmax('reverse',Tr_output,d2);%反归一化,训练集预测数据
Tr_Observe = mapminmax('reverse',data.YTr,d2);%训练集实测数据
%  测试集
Ts_output = predict(data.BiLSTM.Net,data.XTs,'MiniBatchSize',opt.miniBatchSize);
Ts_output = mapminmax('reverse',Ts_output,d4);%反归一化，预测集预测数据
Ts_Observe = mapminmax('reverse',data.YTs,d4);%预测集实测数据
% % % 验证集
Tv_output = predict(data.BiLSTM.Net,data.XVl,'MiniBatchSize',opt.miniBatchSize);
Tv_output = mapminmax('reverse',Tv_output,d2);%反归一化，预测集预测数据
Tv_Observe = mapminmax('reverse',data.YVl,d2);%预测集实测数据

% 合并
Tr_output = [Tr_output;Tv_output];%反归一化，预测集预测数据
Tr_Observe = [Tr_Observe;Tv_Observe];%预测集实测数据

modelMoNi = [Tr_output;Ts_output];
modelObserve = [Tr_Observe;Ts_Observe];
%% 增加约束
for yue_i = 1:size(Tr_output,1)
    if Tr_output(yue_i)>=0
        Tr_output(yue_i) = Tr_output(yue_i);
    else
        Tr_output(yue_i) = abs(Tr_output(yue_i));
    end
end

for yue_j = 1:size(Ts_output,1)
    if Ts_output(yue_j)>=0
        Ts_output(yue_j) = Ts_output(yue_j);
    else
        Ts_output(yue_j) = abs(Ts_output(yue_j));
    end
end
%% 绘图
figure
plot(Tr_Observe,'r-o','Color',[255 0 0]./255,'linewidth',0.8,'Markersize',4,'MarkerFaceColor',[255 0 0]./255)
hold on
plot(Tr_output,'-s','Color',[0 0 0]./255,'linewidth',0.8,'Markersize',5,'MarkerFaceColor',[0 0 0]./255)
hold off
legend(["真实值" "预测值"])
xlabel("样本")
title("训练集")

figure
plot(Tv_Observe,'r-o','Color',[255 0 0]./255,'linewidth',0.8,'Markersize',4,'MarkerFaceColor',[255 0 0]./255)
hold on
plot(Tv_output,'-s','Color',[0 0 0]./255,'linewidth',0.8,'Markersize',5,'MarkerFaceColor',[0 0 0]./255)
hold off
legend(["真实值" "预测值"])
xlabel("样本")
title("验证集")

figure
plot(Ts_Observe,'-o','Color',[255 255 0]./255,'linewidth',0.8,'Markersize',4,'MarkerFaceColor',[255 0 0]./255)
hold on
plot(Ts_output,'-s','Color',[0 0 0]./255,'linewidth',0.8,'Markersize',5,'MarkerFaceColor',[0 0 0]./255)
hold off
legend(["真实值" "预测值"])
xlabel("样本")
title("测试集")

%%   精度计算
%训练集
num1 = length(Tr_output);
error1 = Tr_Observe-Tr_output;
mae1=sum(abs(error1))/num1; %计算平均绝对误差
mse1=sum(error1.*error1)/num1;  %计算均方误差
rmse1 = sqrt(mse1);%计算均方根误差
NSE1=1-(sum((Tr_Observe-Tr_output).^2)./sum((Tr_Observe-mean(Tr_Observe)).^2));
kge1 = KGE(Tr_output,Tr_Observe);
mape1 = calculateMAPE(Tr_Observe,Tr_output);
%测试期
num2 = length(Ts_output);
error2 = Ts_Observe-Ts_output;
mae2 =sum(abs(error2))/num2; %计算平均绝对误差
mse2=sum(error2.*error2)/num2;  %计算均方误差
rmse2 = sqrt(mse2);%计算均方根误差
NSE2=1-(sum((Ts_Observe-Ts_output).^2)./sum((Ts_Observe-mean(Ts_Observe)).^2));
kge2 = KGE(Ts_output,Ts_Observe);
mape2 = calculateMAPE(Ts_Observe,Ts_output);
%验证期
num3 = length(Tv_output);
error3 = Tv_Observe-Tv_output;
mae3 =sum(abs(error3))/num3; %计算平均绝对误差
mse3=sum(error3.*error3)/num3;  %计算均方误差
rmse3 = sqrt(mse3);%计算均方根误差
NSE3=1-(sum((Tv_Observe-Tv_output).^2)./sum((Tv_Observe-mean(Tv_Observe)).^2));
kge3 = KGE(Tv_output,Tv_Observe);
mape3 = calculateMAPE(Tv_Observe,Tv_output);
%% 输出
disp(' ')
disp('----------------------------------------------------------')

disp(['训练期NSE为：             ',num2str(NSE1)])
disp(['训练期均方误差根rmse为：             ',num2str(rmse1)])
disp(['训练期MAE为：             ',num2str(mae1)])
disp(['训练期KGE：',               num2str(kge1)])
disp(['训练期MAPE：',               num2str(mape1)])

disp(['测试期NSE为：             ',num2str(NSE2)])
disp(['测试期均方误差根rmse为：             ',num2str(rmse2)])
disp(['测试期MAE为：             ',num2str(mae2)])
disp(['测试期kge',                 num2str(kge2)])
disp(['测试期MAPE：',               num2str(mape2)])

disp(['验证期NSE为：             ',num2str(NSE3)])
disp(['验证期均方误差根rmse为：             ',num2str(rmse3)])
disp(['验证期MAE为：             ',num2str(mae3)])
disp(['验证期kge',                 num2str(kge3)])
disp(['验证期MAPE：',               num2str(mape3)])
