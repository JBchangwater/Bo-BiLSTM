function kge = KGE(simulated, observed)
    % 计算模拟结果和观测数据的均值和标准差
    mean_simulated = mean(simulated);
    mean_observed = mean(observed);
    std_simulated = std(simulated);
    std_observed = std(observed);

    % 计算模拟结果和观测数据的相关系数
    correlation = corr(simulated, observed);

    % 计算KGE系数
    kge = 1 - sqrt((correlation - 1)^2 + (std_simulated / std_observed - 1)^2 + (mean_simulated / mean_observed - 1)^2);
end
