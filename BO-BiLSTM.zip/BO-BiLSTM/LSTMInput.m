function data = LSTMInput(data)

for i=1:size(data.XTr,2)
    XTr{i,1} = data.XTr(:,i);
    YTr(i,1) = data.YTr(:,i);
end

for i=1:size(data.XTs,2)
    XTs{i,1} =  data.XTs(:,i);
    YTs(i,1) =  data.YTs(:,i);
end

numberMax = length(XTs)+length(XTr);
numberIndex = round(0.2*numberMax);

data.XTr   = XTr(1:end-numberIndex);
data.YTr   = YTr(1:end-numberIndex);

data.XVl   = XTr(end-numberIndex+1:end);%验证集变量X
data.YVl   = YTr(end-numberIndex+1:end);%验证集因变量Y

data.XTs   = XTs;
data.YTs   = YTs;

end