%% ---------------- 优化的目标函数
function ObjFcn = ObjFcn(opt,data)
ObjFcn = @CostFunction;%代价函数：整个训练集上损失的平均

function [valError,cons,fileName] = CostFunction(optVars)
inputSize    = size(data.X,1);
outputMode   = 'last';
numResponses = 1;
dropoutVal   = .5;

if optVars.isUseBiLSTMLayer == 2
    optVars.isUseBiLSTMLayer = 0;
end

if opt.isUseDropoutLayer % 如果选择遗忘门
    if optVars.NumOfLayer ==1
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...%双向LSTM
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...%LSTM模型
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer==2%隐藏层
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer ==3
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...%一般的LSTM
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer==4
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                dropoutLayer(dropoutVal)
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                dropoutLayer(dropoutVal)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    end%神经网络层数的设置
else % 不设置舍弃层   if dropout layer is false
    if optVars.NumOfLayer ==1
%         if optVars.isUseBiLSTMLayer
        if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer ==2
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer ==3
         if optVars.isUseBiLSTMLayer
%          if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    elseif optVars.NumOfLayer ==4
        if optVars.isUseBiLSTMLayer
%         if opt.isUseBiLSTMLayer
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        else
            opt.layers = [ ...
                sequenceInputLayer(inputSize)
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode','sequence')
                lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                fullyConnectedLayer(numResponses)
                regressionLayer];
        end
    end
end
miniBatchSize    = opt.miniBatchSize;
% maxEpochs        = opt.maxEpochs;
trainingProgress = opt.trainingProgress;
executionEnvironment = opt.executionEnvironment;
validationFrequency  = floor(numel(data.XTr)/miniBatchSize);%验证的频率,四舍五入到最近的整数

opt.opts = trainingOptions(opt.LR, ...%优化器
    'MaxEpochs',optVars.maxEpochs, ...%最大迭代次数
    'GradientThreshold',1, ...
    'InitialLearnRate',optVars.InitialLearnRate, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'L2Regularization',optVars.L2Regularization, ...%L2正则
    'Verbose',1, ...
    'MiniBatchSize',miniBatchSize,...
    'ExecutionEnvironment',executionEnvironment,...
    'ValidationData',{data.XVl,data.YVl}, ...%验证数据集
    'ValidationFrequency',validationFrequency,....
    'Plots',trainingProgress);
disp('BiLSTM网络构建成功。');

% --------------- Train Network
try
    data.BiLSTM.Net = trainNetwork(data.XTr,data.YTr,opt.layers,opt.opts);
    disp('BiLSTM网络成功开始训练。'); %如果网络建立没问题，则运行成功
    data.IsNetTrainSuccess =true;
catch me
    disp('BiLSTM网络训练错误');
    data.IsNetTrainSuccess = false;
    return;
end%试错

close(findall(groot,'Tag','NNET_CNN_TRAININGPLOT_UIFIGURE'))%关闭寻优过程


% predict(data.BiLSTM.Net,data.XVl,'MiniBatchSize',opt.miniBatchSize);%预测验证集%将建立好的网络结构，输入验证数据，进行预测
NSEError = 1-calculateNSE(data.YVl,predict(data.BiLSTM.Net,data.XVl,'MiniBatchSize',opt.miniBatchSize));
valError = NSEError;
% valError = tanh(valError1);
%误差为预测测试集输出数据与实际测试集输出数据的均方根误差
Net  = data.BiLSTM.Net;
Opts = opt.opts;

fieldName = ['ValidationError' strrep(num2str(valError),'.','_')];%strrep:查找并替换字符串%每次迭代会将对应的结构和参数进行保存为mat格式，并以误差数值进行命名
if ismember('OptimizedParams',evalin('base','who'))
    OptimizedParams =  evalin('base', 'OptimizedParams');
    OptimizedParams.(fieldName).Net  = Net;
    OptimizedParams.(fieldName).Opts = Opts;
    assignin('base','OptimizedParams',OptimizedParams);
else
    OptimizedParams.(fieldName).Net  = Net;
    OptimizedParams.(fieldName).Opts = Opts;
    assignin('base','OptimizedParams',OptimizedParams);
end

fileName = num2str(valError) + ".mat";
if opt.isSaveOptimizedValue
    save(fileName,'Net','valError','Opts')
end
cons = [];

end

end
