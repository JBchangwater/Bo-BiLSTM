%% ----利用贝叶斯优化LSTM的参数
function [opt,data] = OptimizeLSTM(opt,data)
if opt.isDispOptimizationLog%如果展示过程运行日志，则isLog为2，不展示则为0
    isLog = 2;
else
    isLog = 0;
end
if opt.isUseOptimizer
    opt.ObjFcn  = ObjFcn(opt,data);
    BayesObject = bayesopt(opt.ObjFcn,opt.optimVars, ...%目标函数构建
        'MaxTime',opt.MaxOptimizationTime, ...%最大时间14*60*60
        'IsObjectiveDeterministic',false, ...%目标动态变化
        'MaxObjectiveEvaluations',opt.MaxItrationNumber,...%贝叶斯最大迭代次数
        'Verbose',isLog,...%
        'UseParallel',false);%并行运算

end
end

