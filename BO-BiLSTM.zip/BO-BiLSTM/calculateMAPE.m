function mape = calculateMAPE(real_data, predicted_data)
    % 计算平均百分比误差（MAPE）
    % 输入参数:
    % real_data: 真实数据
    % predicted_data: 预测数据

    % 确保输入数据长度相同
    if length(real_data) ~= length(predicted_data)
        error('输入数据长度不一致');
    end

    % 计算百分比误差
    errors = abs((real_data - predicted_data) ./ real_data) * 100;

    % 计算MAPE
    mape = mean(errors, 'omitnan');
end
