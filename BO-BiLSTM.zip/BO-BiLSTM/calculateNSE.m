function nse = calculateNSE(observed, simulated)  
    % 计算NSE（Nash-Sutcliffe Efficiency）  
    % observed: 观测值（真实值）  
    % simulated: 模拟值（预测值）  
    
    % 检查输入数据长度是否一致  
    if length(observed) ~= length(simulated)  
        error('观测值和模拟值的长度必须相同');  
    end  
    
    % 计算NSE  
    numerator = sum((observed - simulated).^2); % 计算分子  
    denominator = sum((observed - mean(observed)).^2); % 计算分母  
    
    if denominator == 0  % 防止分母为零  
        error('分母为零，无法计算NSE');  
    end  
    
    nse = 1 - (numerator / denominator); % 计算NSE值  
end